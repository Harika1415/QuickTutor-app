package uk.ac.tees.mad.D3933743.ui.theme.home.data

data class Tutor(
    val id:String? = null,
    val name: String? = null,
    val bio: String? = null,
    val profileUrl: String? = null,
    val subjects: String? = null,
    val rating:String? = null,
    val latitude:String? = null,
    val longitude:String? = null
)